from tests import run_tests

#######################################################
### WE'LL GO OVER THE FIRST THREE EXAMPLES TOGETHER ###
#######################################################

from operator import abs, add, mul

def hypotenuse(x, y):
    """Takes in the lengths of two triangle legs, and outputs the length of that
    triangle's corresponding hypotenuse.

    >>> hypotenuse(9, 12)
    15
    >>> hypotenuse(10, 14)
    17
    """
    ##YOUR CODE HERE##

def distance_between(x1, y1, x2, y2):
    """The distance_between function takes in the x and y coordinates of two
    points on a plane, and returns the distance between them. It may be useful
    to write helper functions!

    NOTE: Can distance be negative?

    >>> distance_between(5, 5, 10, 10)
    7.0710678118654755
    >>> distance_between(0, 0, 20, 20)
    26.8701
    """
    ##YOUR CODE HERE##

def sqrt(x):
    """The square root function takes in a single number, and returns its
    square root.

    >>> sqrt(49)
    7
    >>> sqrt(99)
    9.9498743710662
    """
    ##YOUR CODE HERE##

def square(x):
    """Returns the squared value of the given term.

    >>> square(9)
    81
    >>> square(8)
    64
    """
    ##YOUR CODE HERE##


######################################################
### THE NEXT FUNCTIONS ARE FOR INDIVIDUAL PRACTICE ###
######################################################

def discriminant(a, b, c):
    """The discriminant takes in the coefficients, a, b, and c, of a quadratic
    function in the form (ax^2 + bx + c) and returns its discriminant

    >>> discriminant(4, 2, 5)
    -78
    >>> discriminant(2, 3, 1)
    1
    """
    ##YOUR CODE HERE##

def right_triangle_area(base, height):
    """Takes in the base and height of an arbitrary right triangle, and returns
    the area of the given triangle.
    Assume that all inputs produce a proper right triangle.

    >>> right_triangle_area(10, 5)
    25
    >>> right_triangle_area(16, 8)
    64
    """
    ##YOUR CODE HERE##

def second_to_last(x):
    """Takes in an arbitrary number, and returns the second digit from the right;
    the second to last digit. Assume that all inputs have at least 2 digits.

    >>> second_to_last(9893473478)
    7
    >>> second_to_last(64)
    6
    """
    ##YOUR CODE HERE##

def mul_second_to_lasts(num1, num2):
    """Computes the second to last digits of two constants, num1 and num2, and
    returns their value when multiplied together.

    >>> mul_second_to_lasts(98348973, 98)     --> 7 * 9
    63
    >>> mul_second_to_lasts(18, 45823)        --> 1 * 2
    2
    """
    ##YOUR CODE HERE##

def feet_in_to_cm(feet, inches):
    """Converts an arbitrary height in feet an inches to its equivalent in
    centimeters. Consider using a helper function!
    NOTE: One inch is equal to 2.54 centimeters.

    >>> feet_in_to_cm(6, 5)
    198.58
    >>> feet_in_to_cm(98, 7)
    3004.82
    """
    ##YOUR CODE HERE##

def cm_helper(x):
    """Takes in an argument x and returns its value after being multiplied by
    a factor of 2.54.

    Note where this function is.

    >>> cm_helper(53)
    55.54
    """
    ##YOUR CODE HERE##


#############################
### SOME FOOD FOR THOUGHT ###
#############################

# What is the difference between the last two examples? Which functions can be
#       rearranged by their intended purpose?

# What effect does this have on your code?

if __name__ == "__main__":
    run_tests()
