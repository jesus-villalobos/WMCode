from tests import run_tests

############################################################
############################################################

"""SPECIAL NOTE"""

"""THIS PRACTICE SET WILL NOT HAVE TESTS.
    YOUR JOB IS TO REPLICATE WHAT IS IN THE
    DOCSRINGS, AND ENSURE THAT YOUR FUNCTIONS
    WORK FOR ANY INPUT."""

"""FOLLOW THE SAME STEPS AS THE LESSON, AND
    THE TOPICS COVERED WILL ALLOW YOU TO REPLICATE
    THE TEST CASES IN THE DOCSTRINGS."""

############################################################
############################################################

# Worked example from lesson. You can find a walk-through in the video.
def make_even(x):
    """Iterate through values from 0 to x. Even numbers
    are going to be printed. Odd numbers are going to be multiplied by 3
    and have 1 added to them.

    >>> make_even(10)
    0
    4
    2
    10
    4
    16
    6
    22
    8
    28
    10
    """
    current_value = 0
    while current_value <= x:
        if current_value % 2 == 1:
            print(current_value * 3 + 1)
        else:
            print(current_value)

        current_value = current_value + 1

def serve_lunch_evens(students_in_line):
    """This function is a variation of the original serve_lunch function
    implemented in the lesson. This version will only serve lunch to students
    at an even position in the line, and print different messages, accordingly.

    NOTE: In order to keep track of the current student's number in line, should
            you start counting up from 1 to students_in_line or down from the
            number of students_in_line to 0? How can you take care of this?

    >>> serve_lunch_evens(10)
    This student did not get lunch :(
    One more student got lunch!
    This student did not get lunch :(
    One more student got lunch!
    This student did not get lunch :(
    One more student got lunch!
    This student did not get lunch :(
    One more student got lunch!
    This student did not get lunch :(
    One more student got lunch!
    There are no more students in line.

    >>> serve_lunch_evens(1)
    This student did not get lunch :(
    There are no more students in line.

    >>> serve_lunch_evens(0)
    There are no more students in line.
    """
    ## YOUR CODE HERE ##

    

def hailstone(x):
    """The hailstone sequence is a mathematical sequence that starts at any
    number x, and eventually works its way down to 1. The sequence is governed
    by these rules:
    1. If the term is even, divide it by 2
    2. If the term is odd, multiply it by 3 and add 1
    3. The new number at every step is printed

    NOTE: How can you get rid of decimals?

    >>> hailstone(10)
    10
    5
    16
    8
    4
    2
    1
    >>> hailstone(7)
    7
    22
    11
    34
    17
    52
    26
    13
    40
    20
    10
    5
    16
    8
    4
    2
    1
    """
    ## YOUR CODE HERE ##





if __name__ == "__main__":
    run_tests()
