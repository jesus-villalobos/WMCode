


"""




GO BACK TO THE MAIN FILE!




"""




 
def run_tests():
    from doctest import testmod
    testmod(verbose=True)
