from tests import run_tests
import random

###################################
### Lists for testing functions ###
###################################

first_sample_of_students = ["Tommy", "Jimmy", "Juanito", "Maria", "Bobby", "Jessica", "Melissa", "Danny", "Ashley", "Stephanie", "Ben"]
second_sample_of_students = ["Pablo", "Tomas", "Jennifer", "Alex", "Julian", "Buddy", "Tony"]
third_sample_of_students = ["Candace", "Crystal", "Kimberly", "Dennis"]

def help_with_planning(student_array):
    """Your student activities coordinator needs help planning the next student dance!
    She goes around asking students to help with the planning, but for some reason,
    only every other student she asks agrees (i.e. the students in an even position).

    Given a student_array, help this coordinator simulate her survey. Keep track of the students that agree
    and print out their names at the end.

    >>> help_with_planning(first_sample_of_students)
    The students that agreed to help are:
    Tommy
    Juanito
    Bobby
    Melissa
    Ashley
    Ben
    >>> help_with_planning(second_sample_of_students)
    The students that agreed to help are:
    Pablo
    Jennifer
    Julian
    Tony
    >>> help_with_planning(third_sample_of_students)
    The students that agreed to help are:
    Candace
    Kimberly
    """
    said_yes = []

    _____a_____ = 0
    while _____a_____ < len(_____b_____):
        current_student = student_array[_____a_____]
        if _____a_____ % 2 == 0:
            said_yes.append(_____c_____)
        _____a_____ += 1

    print("The students that agreed to help are: ")
    print_list(_____d______)


def arriving_students(student_list):
    """Every morning, students arrive to school (in non-Covid times). A school
    administrator is curious about who arrives to school at what time. Given
    an array that contains students in the order that arrived, help the administrator
    by returning lists of the following (with their descriptions):

    1. Students that arrived early - The students in the first third of the list
    2. Students that arrived on time - The students in the middle third of the list
    3. Students that arrived late - All other students

    >>> arriving_students(first_sample_of_students)
    Students that arrived early:
    Tommy
    Jimmy
    Juanito
    Students that arrived on time:
    Maria
    Bobby
    Jessica
    Students that arrived late:
    Melissa
    Danny
    Ashley
    Stephanie
    Ben

    >>> arriving_students(third_sample_of_students)
    Students that arrived early:
    Candace
    Students that arrived on time:
    Crystal
    Students that arrived late:
    Kimberly
    Dennis
    """
    one_third = len(_____a_____) // 3
    two_thirds = _____b_____ * 2

    first_third = []
    middle = []
    others = []

    i = 0
    while i < len(_____c_____):
        current_student = student_list[i]
        if i < _____d______:
            first_third.append(_____f_____)
        elif i < _____e_____:
            middle.append(_____f_____)
        else:
            others.append(_____f_____)
        i += __g__

    print("Students that arrived early: ")
    print_list(_____h_____)

    print("Students that arrived on time: ")
    print_list(_____k_____)

    print("Students that arrived late: ")
    print_list(_____m_____)


def print_list(list):
    """Helper function for the first two examples. Prints out all items in a list
    starting from the item at index 0.
    """
    i = 0
    while i < len(list):
        print(list[i])
        i += 1


#####################################
### The next problem HAS NO TESTS ###
#####################################

teachers_subjects = {"Spanish 1": "Mrs. Contreras", "Spanish 2": "Ms. Moreno", "AP Spanish": "Ms. Meehan", "H&W 2": "Coach Rivera", "H&W 1": "Coach Flynn", "Gov/Econ": "Mr. Gagen", "ERWC": "Mr. Calvert"}
classes = ["Spanish 1", "Spanish 2", "AP Spanish", "H&W 2", "H&W 1", "Gov/Econ", "ERWC"]


def guesser(class_array, instructor_dictionary):
    """Someone is interested in guessing the teachers for a few classes. Build a
    game that gives them the subject of a class, and have them guess who teaches
    it, until they guess correctly 3 times in a row.
    """
    num_correct = 0

    while _____a_____ < 3:
        random_class = get_random_class(class_array)
        user_answer = input("Who teaches " + random_class + "? \nEnter Your Answer: ")

        if user_answer == _____d______[_____e_____]:
            num_correct += __g__
            if _____a_____ == 1:
                print("You've gotten " + str(num_correct) + " correct! \n")
            elif _____a_____ == __b__:
                print("Yay! 2 in a row! One more! \n")
            elif _____a_____ == 3:
                print("Congrats!! 3 in a row!! \n")
        else:
            print("Sorry, that's not correct. Let's start again. \n")
            _____c_____ = 0
            return guesser(class_array, instructor_dictionary)


def get_random_class(array):
    """This helper function will return a random choice from the given ARRAY."""
    return random.choice(array)





if __name__ == "__main__":
    run_tests()
