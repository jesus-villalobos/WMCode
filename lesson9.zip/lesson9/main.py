from tests import run_tests

#####################
### LIST PRACTICE ###
#####################

lst = ["batman", "ironman", 45, 82, "superman", "rapunzel", 12, "orange"]

"""
For each of the following, index into the list using lst[] notation.
After you are done, all of the statements should be True.
"""

lst_test1 = ("batman" == lst[0])

lst_test2 = (82 == _______)

lst_test3 = ("rapunzel" == _______)

lst_test4 = ("orange" == _______)

lst_test5 = (45 == _______)

lst_test6 = ("superman" == _______)

lst_test7 = (12 == _______)

lst_test8 = ("ironman" == _______)



"""
Reassign lst with these specifications:
- 98                --> at the index where "superman" is
- "It's March"      --> at the index where "orange" is
- False             --> at the index where 45 is
- "Good Morning"    --> at the index where 12 is
- "x"               --> at the index where "batman" is
- 47                --> at the index where "rapunzel" is
- 98127391283       --> at the index where 82 is
- True              --> at the index where "ironman" is
"""

## YOUR CODE HERE ##

lst[4] = 98


#######################
### CODING PRACTICE ###
#######################

def greeter(lst):
    """greeter takes in a list of users, and prints a greeting for each as:

    Hello there, <name>! Thanks for coming :)

    >>> greeter(["Candace", "Crystal", "Kimberly", "Dennis"])
    Hello there, Candace! Thanks for coming :)
    Hello there, Crystal! Thanks for coming :)
    Hello there, Kimberly! Thanks for coming :)
    Hello there, Dennis! Thanks for coming :)
    """
    ## YOUR CODE HERE ##


def iter_lst(lst):
    """Iterate through a given list and print each item
    >>> iter_lst([1, 2, 3, 4, 5, 6, 7])
    1
    2
    3
    4
    5
    6
    7
    >>> iter_lst(["one", 2, "three", "tomorrow", 923, "ironman", "my name is tomas", 21])
    one
    2
    three
    tomorrow
    923
    ironman
    my name is tomas
    21
    """
    ## YOUR CODE HERE ##


def change_list(lst):
    """Iterate through the given lst, and reassign each value to contain what was
    originally there, plus a smily face.

    NOTE: You should not print anything out. I will test that using the iter_lst
    function that you wrote above.

    >>> iter_lst(change_list(["one", "two", "three", "four", "five", "six", "seven"]))
    one :)
    two :)
    three :)
    four :)
    five :)
    six :)
    seven :)
    >>> iter_lst(change_list(["turn", "that", "frown", "upside", "down"]))
    turn :)
    that :)
    frown :)
    upside :)
    down :)
    """
    new_lst = []
    ______ = ________
    while _______ < _________:

        ## YOUR CODE HERE ##

    return new_lst


if __name__ == "__main__":
    run_tests()
