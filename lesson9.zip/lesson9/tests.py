
def run_tests():
    import main

    print("\n=== Running tests for Lesson 9 ===")

    assert main.lst_test1 == True, "Got: " + main.lst_test1 + " Remember indexes start at 0, and double check statements :)"
    assert main.lst_test2 == True, "Got: " + main.lst_test2 + " Remember indexes start at 0, and double check statements :)"
    assert main.lst_test3 == True, "Got: " + main.lst_test3 + " Remember indexes start at 0, and double check statements :)"
    assert main.lst_test4 == True, "Got: " + main.lst_test4 + " Remember indexes start at 0, and double check statements :)"
    assert main.lst_test5 == True, "Got: " + main.lst_test5 + " Remember indexes start at 0, and double check statements :)"
    assert main.lst_test6 == True, "Got: " + main.lst_test6 + " Remember indexes start at 0, and double check statements :)"
    assert main.lst_test7 == True, "Got: " + main.lst_test7 + " Remember indexes start at 0, and double check statements :)"
    assert main.lst_test8 == True, "Got: " + main.lst_test8 + " Remember indexes start at 0, and double check statements :)"

    print("\n=== Tests passed for list indexing! ===\n")

    assert main.lst == ["x", True, False, 98127391283, 98, 47, "Good Morning", "It's March"]

    print("=== Tests passed for list assigment. ===\n")

    from doctest import testmod
    testmod(verbose=True)

    print("\n=== Check tests ^^^ for function writing ^^^ ===\n")

    print("\n=== All Tests Passed!!! ===\n")
